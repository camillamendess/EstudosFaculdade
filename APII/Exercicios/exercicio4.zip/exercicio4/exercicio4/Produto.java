package exercicio4;

/*4 - Escreva uma classe em Java que representa produtos de uma loja. Um produto tem os seguintes dados:
código, nome, quantidade, valor. Escreva os seguintes métodos para esta classe:
calcularPreco - calcula o valor que o produto deve ser vendido (20% a mais do valor de compra).
calcularVenda - recebe a quantidade de produto vendido, calcula e retorna o valor a ser pago pelo
cliente (quantidade * preço)
imprimirProduto
Escreva um programa principal para testar a classe Produto*/


public class Produto {
    int codigo;
    String nome;
    int quantidade;
    double valor;
    double preco;
    double total;

    void calcularPreco(){
        preco = this.valor * 1.2;
    }

    void calcularVenda(){
        total = this.quantidade * this.preco;
    }

    void imprimirProduto(){
        System.out.println("\nCódigo: " + this.codigo);
        System.out.println("Nome: " + this.nome);
        System.out.println("Quantidade: " + this.quantidade);
        System.out.println("Preço da Unidade: " + this.preco);
        System.out.println("Total da compra: " + this.total);
    }
}

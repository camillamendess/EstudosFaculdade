package exercicio4;
import java.util.Scanner;

public class Principal {
    
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        Produto p1 = new Produto();

        System.out.println("Digita o codigo: ");
        p1.codigo = entrada.nextInt();

        System.out.println("Digita o nome: ");
        p1.nome = entrada.next();

        System.out.println("Digita a quantidade: ");
        p1.quantidade = entrada.nextInt();

        System.out.println("Digita o valor: ");
        p1.valor = entrada.nextFloat();

        entrada.close();

        p1.calcularPreco();
        p1.calcularVenda();
        p1.imprimirProduto();


    }
}
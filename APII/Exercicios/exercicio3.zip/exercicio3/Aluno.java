package exercicio3;

public class Aluno {
    int matricula;
    String nome;
    double notaProva1;
    double notaProva2;
    double notaTrabalho;
    double media = ((notaProva1 * 4) + (notaProva2 * 4) + (notaTrabalho * 2)/10);
    double need;

    void calcularMedia() {      //calcularMedia - calcula a média final do aluno (cada prova tem peso 4 e o trabalho tem peso 2)
        media = (((notaProva1 * 4) + (notaProva2 * 4) + (notaTrabalho * 2))/10);
    }

    void calcularFinal() {    //calcularFinal - calcula quanto o aluno precisa para a prova final (retorna zero se ele não for para a final)
        if (this.media > 7){
            need = 0;
        } else {
            need = (10 - this.media);

        }
    }

    void imprimirAluno(){     // imprimirAluno - retorna uma String com os dados do aluno
        System.out.println("Aluno: " + this.nome);
        System.out.println("Matrícula: " + this.matricula);
        System.out.println("Nota da Prova 1: " + this.notaProva1);
        System.out.println("Nota da Prova 2: " + this.notaProva2);
        System.out.println("Nota do Trabalho: " + this.notaTrabalho);
        System.out.println("Média: " + this.media);
        System.out.println("Precisa de: " + this.need);
    }

}

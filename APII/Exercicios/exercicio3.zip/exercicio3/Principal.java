package exercicio3;
import java.util.Scanner;

public class Principal {
    
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        int x = 0;
		System.out.println("Digite quantos alunos: ");
		x = entrada.nextInt();
		Aluno[] arr = new Aluno[x];


        for (int i=0; i<x; i++){

            Aluno a = new Aluno();

            System.out.println("Digite os dados do Aluno " + (i+1));

            System.out.println("Matrícula: ");
            a.matricula = entrada.nextInt();

            System.out.println("Nome: ");
            a.nome = entrada.next();

            System.out.println("Notas: ");
            a.notaProva1 = entrada.nextDouble();
            a.notaProva2 = entrada.nextDouble();
            a.notaTrabalho = entrada.nextDouble();

            arr[i] = a;
        }

        for(int i=0; i<x; i++){

            System.out.println("\nAluno " + (i+1) + ": ");

            arr[i].calcularMedia();

            arr[i].calcularFinal();
        
            arr[i].imprimirAluno();

        }

        entrada.close();

    }
}
